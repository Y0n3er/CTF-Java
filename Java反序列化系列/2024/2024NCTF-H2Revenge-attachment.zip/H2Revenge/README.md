# H2 Revenge

Revenge? 何时来的?