package com.erlo.utils;

import redis.clients.jedis.Jedis;

public class CacheUtil {
    private static final String REDIS_HOST = "redis";
    private static final int REDIS_PORT = 6379;

    private static Jedis getJedis() {
        return new Jedis(REDIS_HOST, REDIS_PORT);
    }

    public static void set(byte[] key, byte[] value) {
        try (Jedis jedis = getJedis()) {
            jedis.set(key, value);
        }
    }
    public static byte[] get(byte[] key) {
        try (Jedis jedis = getJedis()) {
            return jedis.get(key);
        }
    }

    public static void setWithExpiry(byte[] key, byte[] value, int seconds) {
        try (Jedis jedis = getJedis()) {
            jedis.setex(key, seconds, value);
        }
    }
}
