package com.erlo.servlet;


import com.erlo.utils.CacheUtil;
//import com.erlo.utils.LoginUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;

@WebServlet("/main")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String encodedPassword = request.getParameter("password");
        encodedPassword = encodedPassword.replace(" ", "+");

        byte[] password = Base64.getDecoder().decode(encodedPassword);

        // database deleted
        // just login as wwj

        boolean success = "wwj".equals(username) && "20240326".equals(new String(password));

        if (success) {
            CacheUtil.setWithExpiry(("success::" + username).getBytes(), password, 600);
        } else {
            CacheUtil.setWithExpiry(("fail::" + username).getBytes(), password, 600);
        }

        request.setAttribute("username", username);
        request.setAttribute("success", success);
        request.getRequestDispatcher("main.jsp").forward(request, response);
    }
}
