package com.baidu.openrasp;

import com.baidu.openrasp.cloud.model.HookWhiteModel;
import com.baidu.openrasp.config.Config;
import com.baidu.openrasp.exceptions.SecurityException;
import com.baidu.openrasp.hook.xxe.XXEHook;
import com.baidu.openrasp.log4j.Logger;
import com.baidu.openrasp.messaging.ErrorType;
import com.baidu.openrasp.messaging.LogTool;
import com.baidu.openrasp.plugin.checker.CheckParameter;
import com.baidu.openrasp.plugin.checker.CheckerManager;
import com.baidu.openrasp.request.AbstractRequest;
import com.baidu.openrasp.request.DubboRequest;
import com.baidu.openrasp.request.HttpServletRequest;
import com.baidu.openrasp.response.HttpServletResponse;
import com.baidu.openrasp.transformer.CustomClassTransformer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/* loaded from: rasp-engine.jar:com/baidu/openrasp/HookHandler.class */
public class HookHandler {
    public static final String OPEN_RASP_HEADER_KEY = "X-Protected-By";
    public static final String OPEN_RASP_HEADER_VALUE = "OpenRASP";
    public static final String REQUEST_ID_HEADER_KEY = "X-Request-ID";
    public static AtomicLong requestSum = new AtomicLong(0);
    public static final Logger LOGGER = Logger.getLogger(HookHandler.class.getName());
    public static final AtomicBoolean enableHook = new AtomicBoolean(false);
    private static ThreadLocal<Boolean> enableCurrThreadHook = new ThreadLocal<Boolean>() { // from class: com.baidu.openrasp.HookHandler.1
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public Boolean initialValue() {
            return false;
        }
    };
    private static ThreadLocal<Boolean> tmpEnableCurrThreadHook = new ThreadLocal<Boolean>() { // from class: com.baidu.openrasp.HookHandler.2
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public Boolean initialValue() {
            return false;
        }
    };
    public static ThreadLocal<AbstractRequest> requestCache = new ThreadLocal<AbstractRequest>() { // from class: com.baidu.openrasp.HookHandler.3
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public AbstractRequest initialValue() {
            return null;
        }
    };
    public static ThreadLocal<HttpServletResponse> responseCache = new ThreadLocal<HttpServletResponse>() { // from class: com.baidu.openrasp.HookHandler.4
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public HttpServletResponse initialValue() {
            return null;
        }
    };
    public static ThreadLocal<Boolean> enableXssHook = new ThreadLocal<Boolean>() { // from class: com.baidu.openrasp.HookHandler.5
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public Boolean initialValue() {
            return true;
        }
    };
    public static ThreadLocal<Boolean> enableCmdHook = new ThreadLocal<Boolean>() { // from class: com.baidu.openrasp.HookHandler.6
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public Boolean initialValue() {
            return true;
        }
    };
    private static final Map<String, Object> EMPTY_MAP = new HashMap();
    public static ThreadLocal<Boolean> enableEnd = new ThreadLocal<Boolean>() { // from class: com.baidu.openrasp.HookHandler.7
        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.lang.ThreadLocal
        public Boolean initialValue() {
            return true;
        }
    };

    public static void disableCurrThreadHook() {
        enableCurrThreadHook.set(false);
    }

    public static void enableCurrThreadHook() {
        enableCurrThreadHook.set(true);
    }

    public static boolean isEnableCurrThreadHook() {
        return enableCurrThreadHook.get().booleanValue();
    }

    public static void disableBodyXssHook() {
        enableXssHook.set(false);
    }

    public static void enableBodyXssHook() {
        enableXssHook.set(true);
    }

    public static boolean isEnableXssHook() {
        return enableXssHook.get().booleanValue();
    }

    public static void checkCommon(String className, String method, String desc, Object... args) {
        LOGGER.debug("checkCommon: " + className + ":" + method + ":" + desc + StringUtils.SPACE + Arrays.toString(args));
    }

    public static void preShieldHook() {
        tmpEnableCurrThreadHook.set(enableCurrThreadHook.get());
        disableCurrThreadHook();
    }

    public static void postShieldHook() {
        if (tmpEnableCurrThreadHook.get().booleanValue()) {
            enableCurrThreadHook();
        }
    }

    public static void checkRequest(Object servlet, Object request, Object response) {
        if (servlet != null && request != null && !enableCurrThreadHook.get().booleanValue() && CustomClassTransformer.isNecessaryHookComplete) {
            enableEnd.set(true);
            enableCurrThreadHook.set(true);
            enableBodyXssHook();
            HttpServletRequest requestContainer = new HttpServletRequest(request);
            HttpServletResponse responseContainer = new HttpServletResponse(response);
            responseContainer.setHeader(REQUEST_ID_HEADER_KEY, requestContainer.getRequestId());
            setUserDefinedResponseHeader(responseContainer);
            requestCache.set(requestContainer);
            responseCache.set(responseContainer);
            XXEHook.resetLocalExpandedSystemIds();
            doCheck(CheckParameter.Type.REQUEST, EMPTY_MAP);
        }
    }

    public static void checkDubboRequest(Object request) {
        if (request != null && !enableCurrThreadHook.get().booleanValue() && CustomClassTransformer.isDubboNecessaryHookComplete) {
            enableCurrThreadHook.set(true);
            enableBodyXssHook();
            DubboRequest requestContainer = new DubboRequest(request);
            requestCache.set(requestContainer);
            XXEHook.resetLocalExpandedSystemIds();
            doCheck(CheckParameter.Type.REQUEST, EMPTY_MAP);
        }
    }

    public static void onServiceExit() {
        enableCurrThreadHook.set(false);
        requestCache.set(null);
    }

    public static void onDubboExit() {
        enableCurrThreadHook.set(false);
        requestCache.set(null);
    }

    public static void checkFilterRequest(Object filter, Object request, Object response) {
        requestSum.incrementAndGet();
        checkRequest(filter, request, response);
    }

    public static void checkDubboFilterRequest(Object request) {
        checkDubboRequest(request);
    }

    public static void onParseParameters() {
        AbstractRequest request = requestCache.get();
        if (request != null) {
            request.setCanGetParameter(true);
        }
    }

    private static void handleBlock(CheckParameter parameter) {
        SecurityException securityException = new SecurityException("Request blocked by OpenRASP");
        if (responseCache.get() != null) {
            responseCache.get().sendError(parameter);
        }
        throw securityException;
    }

    private static void setUserDefinedResponseHeader(HttpServletResponse response) {
        Map<Object, Object> headers = Config.getConfig().getResponseHeaders();
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<Object, Object> entry : headers.entrySet()) {
                response.setHeader(entry.getKey().toString(), entry.getValue().toString());
            }
        }
    }

    public static void doRealCheckWithoutRequest(CheckParameter.Type type, Map params) {
        if (!enableHook.get()) {
            return;
        }
        long a = 0;
        if (Config.getConfig().getDebugLevel() > 0) {
            a = System.currentTimeMillis();
        }
        boolean isBlock = false;
        CheckParameter parameter = new CheckParameter(type, params);
        try {
            isBlock = CheckerManager.check(type, parameter);
        } catch (Throwable e) {
            String msg = "plugin check error: " + e.getClass().getName() + " because: " + e.getMessage();
            AbstractRequest request = requestCache.get();
            if (request != null) {
                StringBuffer url = request.getRequestURL();
                if (!StringUtils.isEmpty(url)) {
                    msg = ((Object) url) + StringUtils.SPACE + msg;
                }
            }
            LogTool.error(ErrorType.PLUGIN_ERROR, msg, e);
        }
        if (a > 0) {
            long t = System.currentTimeMillis() - a;
            String message = "type=" + type.getName() + StringUtils.SPACE + "time=" + t;
            if (requestCache.get() != null) {
                LOGGER.info("request_id=" + requestCache.get().getRequestId() + StringUtils.SPACE + message);
            } else {
                LOGGER.info(message);
            }
        }
        if (isBlock) {
            handleBlock(parameter);
        }
    }

    public static void doCheckWithoutRequest(CheckParameter.Type type, Map params) {
        boolean enableHookCache = enableCurrThreadHook.get().booleanValue();
        try {
            enableCurrThreadHook.set(false);
            if (Config.getConfig().getDisableHooks()) {
                return;
            }
            if (Config.getConfig().getCloudSwitch() && Config.getConfig().getHookWhiteAll()) {
                enableCurrThreadHook.set(Boolean.valueOf(enableHookCache));
                return;
            }
            if (requestCache.get() != null) {
                try {
                    StringBuffer sb = requestCache.get().getRequestURL();
                    if (sb != null) {
                        String url = sb.substring(sb.indexOf("://") + 3);
                        if (HookWhiteModel.isContainURL(type.getCode(), url)) {
                            enableCurrThreadHook.set(Boolean.valueOf(enableHookCache));
                            return;
                        }
                    }
                } catch (Exception e) {
                    LogTool.traceWarn(ErrorType.HOOK_ERROR, "white list check has failed: " + e.getMessage(), e);
                }
            }
            doRealCheckWithoutRequest(type, params);
            enableCurrThreadHook.set(Boolean.valueOf(enableHookCache));
        } catch (Throwable t) {
            try {
                if (t instanceof SecurityException) {
                    throw ((SecurityException) t);
                }
                enableCurrThreadHook.set(Boolean.valueOf(enableHookCache));
            } finally {
                enableCurrThreadHook.set(Boolean.valueOf(enableHookCache));
            }
        }
    }

    public static void doCheck(CheckParameter.Type type, Map params) {
        if (enableCurrThreadHook.get().booleanValue()) {
            doCheckWithoutRequest(type, params);
        }
    }
}