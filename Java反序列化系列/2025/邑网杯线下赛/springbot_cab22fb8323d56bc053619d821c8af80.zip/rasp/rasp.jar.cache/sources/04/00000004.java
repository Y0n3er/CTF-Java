package com.baidu.openrasp;

import java.io.File;
import java.io.FilenameFilter;
import java.io.UnsupportedEncodingException;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLDecoder;

/* loaded from: rasp.jar:com/baidu/openrasp/ModuleLoader.class */
public class ModuleLoader {
    public static final String ENGINE_JAR = "rasp-engine.jar";
    private static ModuleContainer engineContainer;
    public static String baseDirectory;
    private static ModuleLoader instance;
    public static ClassLoader moduleClassLoader;

    static {
        ClassLoader systemClassLoader;
        try {
            Class clazz = Class.forName("java.nio.file.FileSystems");
            clazz.getMethod("getDefault", new Class[0]).invoke(null, new Object[0]);
        } catch (Throwable th) {
        }
        String path = ModuleLoader.class.getResource("/" + ModuleLoader.class.getName().replace(".", "/") + ".class").getPath();
        if (path.startsWith("file:")) {
            path = path.substring(5);
        }
        if (path.contains("!")) {
            path = path.substring(0, path.indexOf("!"));
        }
        try {
            baseDirectory = URLDecoder.decode(new File(path).getParent(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            baseDirectory = new File(path).getParent();
        }
        ClassLoader systemClassLoader2 = ClassLoader.getSystemClassLoader();
        while (true) {
            systemClassLoader = systemClassLoader2;
            if (systemClassLoader.getParent() == null || systemClassLoader.getClass().getName().equals("sun.misc.Launcher$ExtClassLoader")) {
                break;
            }
            systemClassLoader2 = systemClassLoader.getParent();
        }
        moduleClassLoader = systemClassLoader;
    }

    private ModuleLoader(String mode, Instrumentation inst) throws Throwable {
        if (Module.START_MODE_NORMAL == mode) {
            setStartupOptionForJboss();
        }
        engineContainer = new ModuleContainer(ENGINE_JAR);
        engineContainer.start(mode, inst);
    }

    public static synchronized void release(String mode) {
        try {
            if (engineContainer != null) {
                System.out.println("[OpenRASP] Start to release OpenRASP");
                engineContainer.release(mode);
                engineContainer = null;
            } else {
                System.out.println("[OpenRASP] Engine is initialized, skipped");
            }
        } catch (Throwable th) {
        }
    }

    public static synchronized void load(String mode, String action, Instrumentation inst) throws Throwable {
        if (Module.START_ACTION_INSTALL.equals(action)) {
            if (instance == null) {
                try {
                    instance = new ModuleLoader(mode, inst);
                    return;
                } catch (Throwable t) {
                    instance = null;
                    throw t;
                }
            }
            System.out.println("[OpenRASP] The OpenRASP has bean initialized and cannot be initialized again");
        } else if (Module.START_ACTION_UNINSTALL.equals(action)) {
            release(mode);
        } else {
            throw new IllegalStateException("[OpenRASP] Can not support the action: " + action);
        }
    }

    public static boolean isCustomClassloader() {
        try {
            String classLoader = ClassLoader.getSystemClassLoader().getClass().getName();
            if (classLoader.startsWith("com.oracle") && classLoader.contains("weblogic")) {
                return true;
            }
            return isModularityJdk();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isModularityJdk() {
        String javaVersion = System.getProperty("java.version");
        String[] version = javaVersion.split("\\.");
        if (version.length >= 2) {
            try {
                int major = Integer.parseInt(version[0]);
                int minor = Integer.parseInt(version[1]);
                if (major == 1) {
                    return minor >= 9;
                } else if (major >= 9) {
                    return true;
                } else {
                    return false;
                }
            } catch (NumberFormatException e) {
                return false;
            }
        } else if (javaVersion.startsWith("9")) {
            return true;
        } else {
            if (javaVersion.length() >= 2) {
                char first = javaVersion.charAt(0);
                char second = javaVersion.charAt(1);
                if (first >= '1' && first <= '9' && second >= '0' && second <= '9') {
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    public static void setStartupOptionForJboss() {
        String moduleBaseDir;
        String jbossHome = "";
        boolean isJboss = false;
        String splitChar = System.getProperty("path.separator") == null ? ";" : System.getProperty("path.separator");
        String[] jarPaths = System.getProperty("java.class.path").split(splitChar);
        int i = 0;
        while (true) {
            if (i >= jarPaths.length) {
                break;
            } else if (!jarPaths[i].endsWith("jboss-modules.jar")) {
                i++;
            } else {
                File jarFile = new File(jarPaths[i]);
                if (null != jarFile) {
                    jbossHome = jarFile.getParent();
                }
                isJboss = true;
            }
        }
        if (isJboss) {
            File moduleBase = new File(jbossHome + "/modules/system/layers/base");
            if (null != moduleBase && moduleBase.isDirectory()) {
                moduleBaseDir = jbossHome + "/modules/system/layers/base";
            } else {
                moduleBaseDir = jbossHome + "/modules";
            }
            setSystemProperty(moduleBaseDir);
        }
    }

    public static void setSystemProperty(String moduleBaseDir) {
        String pkgs;
        String pkgs2 = System.getProperty("jboss.modules.system.pkgs");
        System.out.println("origin pkgs = " + pkgs2);
        if (null == pkgs2 || !pkgs2.contains("baidu.openrasp")) {
            if (pkgs2 != null && !pkgs2.isEmpty()) {
                pkgs = System.setProperty("jboss.modules.system.pkgs", pkgs2 + ",org.jboss.logmanager,com.baidu.openrasp,com.sdwaf,javax.servlet,javax.el");
            } else {
                pkgs = System.setProperty("jboss.modules.system.pkgs", "org.jboss.logmanager,com.baidu.openrasp,com.sdwaf,javax.servlet,javax.el");
            }
            System.out.println("default pkgs = " + System.setProperty("jboss.modules.system.pkgs", pkgs + ",org.jboss.logmanager,com.baidu.openrasp,com.sdwaf,javax.servlet,javax.el"));
        }
        String logManager = System.getProperty("java.util.logging.manager");
        System.out.println("origin java.util.logging.manager = " + logManager);
        if (null == logManager || logManager.isEmpty()) {
            System.setProperty("java.util.logging.manager", "org.jboss.logmanager.LogManager");
            System.out.println("add org.jboss.logmanager.LogManager to java.util.logging.manager");
        } else if (!logManager.contains("org.jboss.logmanager.LogManager")) {
            System.setProperty("java.util.logging.manager", logManager + ",org.jboss.logmanager.LogManager");
            System.out.println("add logmanager on old value=" + logManager);
        }
        String splitChar = System.getProperty("path.separator") == null ? ";" : System.getProperty("path.separator");
        String logBootPath = appendPathAfterLoadJar(appendPathAfterLoadJar(appendPathAfterLoadJar(appendPathAfterLoadJar(appendPathAfterLoadJar("", moduleBaseDir + "/org/jboss/logmanager/main/", "jboss-logmanager-"), moduleBaseDir + "/org/jboss/log4j/logmanager/main/", "jboss-logmanager-"), moduleBaseDir + "/org/jboss/logmanager/log4j/main/", "jboss-logmanager-"), moduleBaseDir + "/org//apache//log4j/main/", "log4j-"), moduleBaseDir + "/org/wildfly/common/main/", "wildfly-common-");
        String bootClasspath = System.getProperty("sun.boot.class.path");
        if (null == bootClasspath || bootClasspath.isEmpty()) {
            System.setProperty("sun.boot.class.path", logBootPath);
        } else if (false == bootClasspath.contains("jboss-logmanager")) {
            String logBootPath2 = logBootPath + splitChar + bootClasspath;
            System.setProperty("sun.boot.class.path", logBootPath2);
            System.out.println("add boot classpath on value=" + logBootPath2);
        }
        loadJarFromPath(moduleBaseDir + "/javax/servlet/jsp/api/main/", "jsp-api");
        loadJarFromPath(moduleBaseDir + "/javax/servlet/jstl/api/main/", "jstl-api");
        loadJarFromPath(moduleBaseDir + "/javax/servlet/jstl/api/main/", "taglibs-standard-");
        loadJarFromPath(moduleBaseDir + "/javax/el/api/main/", "el-api");
        loadJarFromPath(moduleBaseDir + "/javax/servlet/api/main/", "servlet-api");
    }

    public static String appendPathAfterLoadJar(String oldPath, String libPath, String jarName) {
        String newPath = oldPath;
        String splitChar = System.getProperty("path.separator") == null ? ";" : System.getProperty("path.separator");
        String jarPath = loadJarFromPath(libPath, jarName);
        if (false == jarPath.isEmpty()) {
            newPath = oldPath.isEmpty() ? jarPath : jarPath + splitChar + oldPath;
        }
        return newPath;
    }

    public static String loadJarFromPath(String libPath, String jarName) {
        String jarPath = "";
        File libDir = new File(libPath);
        if (false == libDir.isDirectory()) {
            System.out.println("library path:" + libPath + " is not directory.");
            return jarPath;
        }
        File[] jarFiles = libDir.listFiles(new FilenameFilter() { // from class: com.baidu.openrasp.ModuleLoader.1
            @Override // java.io.FilenameFilter
            public boolean accept(File dir, String name) {
                return name.endsWith(".jar");
            }
        });
        for (File file : jarFiles) {
            String filePath = file.getAbsolutePath();
            if (filePath != null && filePath.contains(jarName)) {
                loadJar(file);
                jarPath = file.getAbsolutePath();
            }
        }
        return jarPath;
    }

    public static boolean loadJar(File file) {
        boolean loadResult = true;
        try {
            Method method = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
            boolean accessible = method.isAccessible();
            if (!accessible) {
                method.setAccessible(true);
            }
            try {
                URL url = file.toURI().toURL();
                if (moduleClassLoader instanceof URLClassLoader) {
                    method.invoke(moduleClassLoader, url);
                } else if (isCustomClassloader()) {
                    moduleClassLoader = ClassLoader.getSystemClassLoader();
                    method = moduleClassLoader.getClass().getDeclaredMethod("appendToClassPathForInstrumentation", String.class);
                    method.setAccessible(true);
                    try {
                        method.invoke(moduleClassLoader, file.getCanonicalPath());
                    } catch (Exception e) {
                        method.invoke(moduleClassLoader, file.getAbsolutePath());
                    }
                }
            } catch (Exception localException) {
                loadResult = false;
                localException.printStackTrace();
            }
            method.setAccessible(accessible);
        } catch (NoSuchMethodException e1) {
            loadResult = false;
            e1.printStackTrace();
        } catch (SecurityException e12) {
            loadResult = false;
            e12.printStackTrace();
        }
        return loadResult;
    }
}