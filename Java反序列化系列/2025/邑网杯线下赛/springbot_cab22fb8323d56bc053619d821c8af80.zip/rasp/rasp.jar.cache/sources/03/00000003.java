package com.baidu.openrasp;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.jar.Attributes;
import java.util.jar.JarFile;

/* loaded from: rasp.jar:com/baidu/openrasp/ModuleContainer.class */
public class ModuleContainer implements Module {
    private Module module;
    private String moduleName;

    public ModuleContainer(String jarName) throws Throwable {
        try {
            File originFile = new File(ModuleLoader.baseDirectory + File.separator + jarName);
            JarFile jarFile = new JarFile(originFile);
            Attributes attributes = jarFile.getManifest().getMainAttributes();
            jarFile.close();
            this.moduleName = attributes.getValue("Rasp-Module-Name");
            String moduleEnterClassName = attributes.getValue("Rasp-Module-Class");
            if (this.moduleName != null && moduleEnterClassName != null && !this.moduleName.equals("") && !moduleEnterClassName.equals("")) {
                if (ClassLoader.getSystemClassLoader() instanceof URLClassLoader) {
                    Method method = Class.forName("java.net.URLClassLoader").getDeclaredMethod("addURL", URL.class);
                    method.setAccessible(true);
                    method.invoke(ModuleLoader.moduleClassLoader, originFile.toURI().toURL());
                    method.invoke(ClassLoader.getSystemClassLoader(), originFile.toURI().toURL());
                    Class moduleClass = ModuleLoader.moduleClassLoader.loadClass(moduleEnterClassName);
                    this.module = (Module) moduleClass.newInstance();
                } else if (ModuleLoader.isCustomClassloader()) {
                    ModuleLoader.moduleClassLoader = ClassLoader.getSystemClassLoader();
                    Method method2 = ModuleLoader.moduleClassLoader.getClass().getDeclaredMethod("appendToClassPathForInstrumentation", String.class);
                    method2.setAccessible(true);
                    try {
                        method2.invoke(ModuleLoader.moduleClassLoader, originFile.getCanonicalPath());
                    } catch (Exception e) {
                        method2.invoke(ModuleLoader.moduleClassLoader, originFile.getAbsolutePath());
                    }
                    Class moduleClass2 = ModuleLoader.moduleClassLoader.loadClass(moduleEnterClassName);
                    this.module = (Module) moduleClass2.newInstance();
                } else {
                    throw new Exception("[OpenRASP] Failed to initialize module jar: " + jarName);
                }
            }
        } catch (Throwable t) {
            System.err.println("[OpenRASP] Failed to initialize module jar: " + jarName);
            throw t;
        }
    }

    @Override // com.baidu.openrasp.Module
    public void start(String mode, Instrumentation inst) throws Throwable {
        this.module.start(mode, inst);
    }

    @Override // com.baidu.openrasp.Module
    public void release(String mode) throws Throwable {
        try {
            if (this.module != null) {
                this.module.release(mode);
            }
        } catch (Throwable t) {
            System.err.println("[OpenRASP] Failed to release module: " + this.moduleName);
            throw t;
        }
    }
}