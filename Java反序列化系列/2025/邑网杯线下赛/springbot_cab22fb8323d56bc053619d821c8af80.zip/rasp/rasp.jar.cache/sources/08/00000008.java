package com.baidu.openrasp.cli;

@Deprecated
/* loaded from: rasp.jar:com/baidu/openrasp/cli/BasicParser.class */
public class BasicParser extends Parser {
    @Override // com.baidu.openrasp.cli.Parser
    protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
        return arguments;
    }
}