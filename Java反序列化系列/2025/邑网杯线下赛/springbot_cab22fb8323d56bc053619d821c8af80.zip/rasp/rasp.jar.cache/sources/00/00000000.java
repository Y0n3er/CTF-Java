package com.baidu.openrasp;

import com.baidu.openrasp.cli.CommandLine;
import com.baidu.openrasp.cli.CommandLineParser;
import com.baidu.openrasp.cli.DefaultParser;
import com.baidu.openrasp.cli.HelpFormatter;
import com.baidu.openrasp.cli.Options;
import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.net.URL;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

/* loaded from: rasp.jar:com/baidu/openrasp/Agent.class */
public class Agent {
    public static String projectVersion;
    public static String buildTime;
    public static String gitCommit;

    public static void main(String[] args) {
        try {
            Options options = new Options();
            options.addOption("h", "help", false, "print options information");
            options.addOption("v", "version", false, "print the version of rasp");
            HelpFormatter helpFormatter = new HelpFormatter();
            CommandLineParser parser = new DefaultParser();
            CommandLine cmd = parser.parse(options, args);
            if (cmd.hasOption("v")) {
                readVersion();
                System.out.println("Version:       " + projectVersion + "\nBuild Time:    " + buildTime + "\nGit Commit ID: " + gitCommit);
            } else if (cmd.hasOption("h")) {
                helpFormatter.printHelp("java -jar rasp.jar", options, true);
            } else {
                helpFormatter.printHelp("java -jar rasp.jar", options, true);
            }
        } catch (Throwable e) {
            System.out.println("failed to parse options\n" + e.getMessage());
        }
    }

    public static void premain(String agentArg, Instrumentation inst) {
        init(Module.START_MODE_NORMAL, Module.START_ACTION_INSTALL, inst);
    }

    public static void agentmain(String agentArg, Instrumentation inst) {
        init(Module.START_MODE_ATTACH, agentArg, inst);
    }

    public static synchronized void init(String mode, String action, Instrumentation inst) {
        try {
            JarFileHelper.addJarToBootstrap(inst);
            readVersion();
            ModuleLoader.load(mode, action, inst);
        } catch (Throwable e) {
            System.err.println("[OpenRASP] Failed to initialize, will continue without security protection.");
            e.printStackTrace();
        }
    }

    public static void readVersion() throws IOException {
        String className = Agent.class.getSimpleName() + ".class";
        String classPath = Agent.class.getResource(className).toString();
        String manifestPath = classPath.substring(0, classPath.lastIndexOf("!") + 1) + "/META-INF/MANIFEST.MF";
        Manifest manifest = new Manifest(new URL(manifestPath).openStream());
        Attributes attr = manifest.getMainAttributes();
        projectVersion = attr.getValue("Project-Version");
        buildTime = attr.getValue("Build-Time");
        gitCommit = attr.getValue("Git-Commit");
        projectVersion = projectVersion == null ? "UNKNOWN" : projectVersion;
        buildTime = buildTime == null ? "UNKNOWN" : buildTime;
        gitCommit = gitCommit == null ? "UNKNOWN" : gitCommit;
    }
}