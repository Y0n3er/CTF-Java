package com.baidu.openrasp;

import java.lang.instrument.Instrumentation;

/* loaded from: rasp.jar:com/baidu/openrasp/Module.class */
public interface Module {
    public static final String START_MODE_ATTACH = "attach";
    public static final String START_MODE_NORMAL = "normal";
    public static final String START_ACTION_INSTALL = "install";
    public static final String START_ACTION_UNINSTALL = "uninstall";

    void start(String str, Instrumentation instrumentation) throws Throwable;

    void release(String str) throws Throwable;
}