package com.baidu.openrasp.cli;

/* loaded from: rasp.jar:com/baidu/openrasp/cli/CommandLineParser.class */
public interface CommandLineParser {
    CommandLine parse(Options options, String[] strArr) throws ParseException;

    CommandLine parse(Options options, String[] strArr, boolean z) throws ParseException;
}