package com.nengyuan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NengyuanApplicationTests {

    @Test
    void contextLoads() {
    }

}
