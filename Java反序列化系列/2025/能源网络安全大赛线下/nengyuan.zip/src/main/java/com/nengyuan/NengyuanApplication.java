package com.nengyuan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NengyuanApplication {

    public static void main(String[] args) {
        SpringApplication.run(NengyuanApplication.class, args);
    }

}
