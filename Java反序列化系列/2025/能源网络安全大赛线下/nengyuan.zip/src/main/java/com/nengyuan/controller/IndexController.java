package com.nengyuan.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.ParserConfig;
//import com.ctf.badjava.entity.User;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class IndexController {
    @GetMapping({"/"})
    public String index() {
        return "index.html";
    }

    @ResponseBody
    @PostMapping({"/login"})
    public String login(HttpServletRequest request, HttpServletResponse response) {
        String data = request.getParameter("data");
        String resp = "Maybe username or password error!";
        if (data == null)
            return JSON.toJSONString(resp);
        Base64.Decoder decoder = Base64.getDecoder();
        String decode = new String(decoder.decode(data), StandardCharsets.UTF_8);
        Pattern p = Pattern.compile("JdbcRowSetImpl|type|dataSourceName|autoCommit|TemplatesImpl|bytecodes|BasicDataSource", 8);
        boolean isMatch = p.matcher(decode).find();
        if (!isMatch)
            try {
                Object user = JSON.parse(decode);
//                User u = new User((String)((JSONObject)user).get("username"), (String)((JSONObject)user).get("password"));
//                if (u.getUsername().equals("ctf") && u.getPassword().equals("ILikeCTFGAMES!!!")) {
//                    resp = "Login Success,flag Is flag{***********}.";
//                } else {
//                    resp = "Maybe Username or Password error!";
//                }
            } catch (Exception var11) {
                resp = "Maybe Username or Password error!";
            }
        return JSON.toJSONString(resp);

    }

    static {
        ParserConfig.getGlobalInstance().addAccept("com.ctf.entity.User");
    }
}

